//
//  SupabaseConfig.swift
//  iOSApprenticeProject
//

import Foundation

enum SupabaseConfig {
    static let url = URL(string: "https://fxahtcoctoadbukbfrsc.supabase.co")!

    /// Paste your anon / publishable key here (Supabase dashboard -> Project Settings -> API).
    /// Never put the service_role key in the app.
    static let anonKey = "PASTE_YOUR_ANON_KEY_HERE"
}
